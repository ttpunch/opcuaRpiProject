from ..opcua_server.server import OPCUAServer

# Global OPC UA Server instance shared across the API
opcua_server = OPCUAServer()
